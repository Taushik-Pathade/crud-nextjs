// Bootstrap Icons
import * as Bs from "react-icons/bs";

// Ant Design Icons
import * as Ai from "react-icons/ai";

// Material Design Icons
import * as Md from "react-icons/md";

// Feather Icons
import * as Fi from "react-icons/fi";

// Font Awesome Icons
import * as Fa from "react-icons/fa";

// Ionicons
import * as Io from "react-icons/io";

import * as Bi from "react-icons/bi";


import * as Hi from "react-icons/hi";

export const Icon = {Bs,Ai,Md,Fi,Fa,Io,Bi,Hi}